"""Review probes for tutorials/bart_summarization_colab.ipynb (prefix BART), review 2026-10-02.

CPU only. No real BART weights: P3-P5 use a TINY RANDOMLY-INITIALISED BartForConditionalGeneration built from the
snapshot's own config.json / generation_config.json (forced_eos_token_id etc. preserved, widths shrunk, 12 decoder
layers kept) and the snapshot's real tokenizer files, staged with a manifest so the carried
BARTSummarizationPipeline.from_pretrained / adapt / evaluate / save_artifact / from_artifact run unmodified.
It exercises the carried control flow and the transformers generation logic, not BART-large-CNN's numerics.

Usage: python run_probes.py <worktree-root> <out-dir>
"""
from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(sys.argv[1]).resolve()
OUT = Path(sys.argv[2]).resolve()
NB = ROOT / "tutorials" / "bart_summarization_colab.ipynb"
sys.path.insert(0, str(ROOT / "src"))
results: dict = {}


def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


# ---- P1: notebook parse / compile / blob / generator check / doubled braces -----------------------------
nb = json.loads(NB.read_text(encoding="utf-8"))
code = [c for c in nb["cells"] if c["cell_type"] == "code"]
compiled = 0
for c in code:
    compile("".join(c["source"]), "<cell>", "exec")
    compiled += 1
blob = subprocess.run(["git", "-C", str(ROOT), "rev-parse", "HEAD:tutorials/bart_summarization_colab.ipynb"],
                      capture_output=True, text=True).stdout.strip()
gen = subprocess.run([sys.executable, str(ROOT / "tools" / "build_notebook.py"), "--check"], cwd=ROOT,
                     capture_output=True, text=True)
doubled = [i for i, c in enumerate(nb["cells"]) if c["cell_type"] == "markdown" and "{{" in "".join(c["source"])]
results["P1_static"] = {
    "cells": len(nb["cells"]), "code_cells": len(code), "compiled": compiled, "blob": blob,
    "generator_check_exit": gen.returncode, "generator_check_tail": (gen.stdout + gen.stderr)[-300:],
    "metadata_notebook_spec": nb["metadata"]["dimer"]["notebook_spec"],
    "markdown_cells_with_doubled_braces": doubled,
}

# ---- P2: BYOD minimum vs the per-split validation the notebook applies (cell 13) ------------------------
from bart_summarization_pipeline.samples import split_dataset, validate_dataset  # noqa: E402

p2 = {}
for n in (8, 20, 37, 38, 49, 50):
    recs0 = [{"id": f"r{i}", "source": f"Document number {i} talks about topic {i}. It has a second sentence.",
              "targets": [f"Topic {i}."]} for i in range(n)]
    validate_dataset(recs0)  # stated contract: 8..20,000 records
    try:
        splits = split_dataset(recs0, seed=42)
        sizes = {k: len(v) for k, v in splits.items()}
        try:
            {name: validate_dataset(part) for name, part in splits.items()}  # exactly cell 13
            p2[n] = {"split_sizes": sizes, "cell13": "passes"}
        except ValueError as exc:
            p2[n] = {"split_sizes": sizes, "cell13": f"ValueError: {exc}"}
    except ValueError as exc:
        p2[n] = {"split_dataset": f"ValueError: {exc}"}
results["P2_byod_minimum"] = p2

# ---- tiny BART snapshot shared by P3-P5 ----------------------------------------------------------------
import torch  # noqa: E402
from transformers import BartConfig, BartForConditionalGeneration, BartTokenizerFast  # noqa: E402

import bart_summarization_pipeline.pipeline as bp  # noqa: E402

snap_src = ROOT / "weights" / "bart-large-cnn"
tmp = Path(tempfile.mkdtemp(prefix="bart_probe_"))
snap = tmp / "snap"
snap.mkdir()
cfg = BartConfig.from_pretrained(str(snap_src))
cfg.update({"d_model": 16, "encoder_layers": 1, "decoder_layers": 12, "encoder_ffn_dim": 32, "decoder_ffn_dim": 32,
            "encoder_attention_heads": 2, "decoder_attention_heads": 2})
torch.manual_seed(0)
BartForConditionalGeneration(cfg).save_pretrained(str(snap), safe_serialization=True)
for name in ("generation_config.json", "generation_config_for_summarization.json", "merges.txt", "tokenizer.json",
             "vocab.json"):
    shutil.copy(snap_src / name, snap / name)
files = sorted(p.name for p in snap.iterdir())
(snap / bp.MANIFEST_NAME).write_text(json.dumps({
    "format": "dimer_hf_snapshot", "formatVersion": 1, "modelKey": bp.MODEL_KEY,
    "modelId": bp.MODEL_ID, "revision": bp.MODEL_REVISION,
    "files": [{"path": f, "bytes": (snap / f).stat().st_size, "sha256": sha(snap / f)} for f in files]}),
    encoding="utf-8")
pipe = bp.BARTSummarizationPipeline.from_pretrained(weights_dir=snap, device="cpu")
tok = BartTokenizerFast.from_pretrained(str(snap_src))
gen_cfg = json.loads((snap_src / "generation_config.json").read_text())

# ---- P3: truncated / stopped_by under forced EOS --------------------------------------------------------
doc = ("The town council of Millbrook voted on Tuesday evening to approve a three-year plan to replace the "
       "aging water mains. ") * 3
p3 = {"snapshot_forced_eos_token_id": gen_cfg.get("forced_eos_token_id"), "eos_token_id": gen_cfg.get("eos_token_id")}
for cap in (6, 10, 16):
    r = pipe.summarize(doc, max_new_tokens=cap, min_new_tokens=0, num_beams=4)
    p3[f"max_new_tokens={cap}"] = {"generated_tokens": r["generated_tokens"], "stopped_by": r["stopped_by"],
                                   "truncated": r["truncated"]}
# Kaggle-recorded outputs (.agent/backups/kaggle-e2e-2026-09-19/.../v2/evidence/executed.ipynb), TL;DR cap 48
kaggle_texts = {
    "section5_tldr (recorded generated_tokens 46, stopped_by eos)":
        "The town council of Millbrook voted on Tuesday evening to approve a three-year plan to replace the aging "
        "water mains beneath the historic district. The plan, which had been debated for more than a year, will cost "
        "an estimated",
    "section6_frozen_example_1 (split recorded hit_token_ceiling 0)":
        "We introduce a new method for training GANs by applying the Wasserstein-2 metric proximal on the generators. "
        "The approach is based on the gradient operator induced by optimal transport. Our experiments demonstrate that "
        "this method improves the",
    "section6_frozen_example_2":
        "Deep neural networks (DNNs) generalize remarkably well without explicit regularization even in the strongly "
        "over-parametrized regime. There is no consensus for the fundamental reason why DNNs do not strongly overfit.",
}
p3["kaggle_recorded_texts_content_tokens"] = {k: len(tok(v, add_special_tokens=False)["input_ids"])
                                              for k, v in kaggle_texts.items()}
p3["content_tokens_when_cap_48_is_hit"] = 48 - 2  # forced BOS + forced EOS occupy two of the 48 new tokens
results["P3_truncation_flag"] = p3


# ---- P4: prescribed reruns on the same pipe -------------------------------------------------------------
def recs(prefix, n, offset=0):
    return [{"id": f"{prefix}{i}",
             "source": f"Paper {i + offset} studies method {i + offset} for task {i % 3}. We report results on benchmark {i}.",
             "targets": [f"We study method {i + offset}."]} for i in range(n)]


train, val, test = recs("t", 16), recs("v", 4, 100), recs("x", 4, 200)
T = {"max_new_tokens": 8, "min_new_tokens": 0, "num_beams": 2}
model = pipe._model
L10 = "model.decoder.layers.10.fc1.weight"
base10 = model.state_dict()[L10].clone()
frozen_eval = pipe.evaluate(test, **T)
# val=None so the trained epoch is kept (the tiny random model scores ROUGE 0 on any val split, so
# validation selection would keep epoch 0); the state mechanics probed here do not depend on selection
first = pipe.adapt(train, None, epochs=1, lr=1e-3, batch_size=8, trainable_decoder_layers=2, eval_generation=T)
after_first10 = model.state_dict()[L10].clone()
rerun_section6 = pipe.evaluate(test, **T)  # what Section 6 "frozen model" prints on a rerun
second = pipe.adapt(train, None, epochs=1, lr=1e-3, batch_size=8, trainable_decoder_layers=1, eval_generation=T)
art = tmp / "adapter"
pipe.save_artifact(art)
reloaded = bp.BARTSummarizationPipeline.from_artifact(art, weights_dir=snap, device="cpu")
man = json.loads((art / "manifest.json").read_text())
with torch.inference_mode():
    enc = tok(test[0]["source"], return_tensors="pt")
    dec = torch.tensor([[2, 0, 100, 200]])
    a = pipe._model(**enc, decoder_input_ids=dec).logits
    b = reloaded._model(**enc, decoder_input_ids=dec).logits
before = [pipe.summarize(r["source"], **T)["summary"] for r in test]
after = [reloaded.summarize(r["source"], **T)["summary"] for r in test]
results["P4_rerun_state"] = {
    "first_run_epoch0_note": first["history"][0].get("note"),
    "first_run_selection": first["selection"],
    "default_section6_adapted_flag": frozen_eval["adapted"],
    "rerun_section6_adapted_flag": rerun_section6["adapted"],
    "second_run_epoch0_note": second["history"][0].get("note"),
    "layer10_changed_by_first_adapt": bool(not torch.equal(base10, after_first10)),
    "layer10_in_pipe_after_second_adapt_equals_first_adapt": bool(torch.equal(model.state_dict()[L10], after_first10)),
    "artifact_tensor_layers": sorted({t.split(".")[3] for t in man["tensors"]}),
    "artifact_trainable_decoder_layers": man["adapter"]["trainable_decoder_layers"],
    "reloaded_layer10_equals_base": bool(torch.equal(reloaded._model.state_dict()[L10], base10)),
    "max_abs_logit_diff_pipe_vs_reloaded": float((a - b).abs().max()),
    "summary_parity_identical": sum(x == y for x, y in zip(before, after)), "of": len(before),
}

# ---- P5: BYOD source over the 1,024-token ceiling passes Section 4 validation, fails inside model execution
long_src = ("Sentence about a long technical report with many words. " * 120).strip()
n_tokens = len(tok(long_src)["input_ids"])
byod = recs("b", 44) + [{"id": f"long-doc-{k}", "source": f"Report {k}. " + long_src, "targets": ["A long report."]}
                         for k in range(6)]
splits = split_dataset(byod, seed=42)
cell13 = {name: validate_dataset(part)["n_records"] for name, part in splits.items()}
where = {name: [r["id"] for r in part if r["id"].startswith("long-doc")] for name, part in splits.items()}
try:
    pipe.evaluate(list(splits["test"]), **T)  # Section 6 frozen evaluation
    p5_err = None
except ValueError as exc:
    p5_err = str(exc)
results["P5_byod_token_ceiling"] = {
    "source_chars": len(long_src), "MAX_TEXT_CHARS": bp.MAX_TEXT_CHARS, "source_tokens": n_tokens,
    "MAX_INPUT_TOKENS": bp.MAX_INPUT_TOKENS, "section4_validation_n_records": cell13, "long_doc_split": where,
    "evaluate_error": p5_err, "error_names_record_id": bool(p5_err and "long-doc" in p5_err),
    "note": "test split evaluated as Section 6 does; Lead baselines (no tokenizer) complete first"}

# ---- P6: result-dependent asserts in learner-facing cells ----------------------------------------------
asserts = []
for i, c in enumerate(nb["cells"]):
    if c["cell_type"] == "code" and not c.get("metadata", {}).get("dimer", {}).get("embedded_module"):
        for line in "".join(c["source"]).splitlines():
            if line.strip().startswith("assert "):
                asserts.append({"cell": i, "line": line.strip()})
results["P6_asserts"] = asserts

shutil.rmtree(tmp, ignore_errors=True)
results["environment"] = {
    "python": sys.version.split()[0], "torch": torch.__version__,
    "transformers": __import__("transformers").__version__, "device": "cpu",
    "note": "tiny random BART stand-in (real config/generation_config/tokenizer) for P3-P5; no real weights"}
OUT.mkdir(parents=True, exist_ok=True)
(OUT / "results.json").write_text(json.dumps(results, indent=2, default=str), encoding="utf-8")
inspected = [NB, *sorted((ROOT / "src" / "bart_summarization_pipeline").glob("*.py")),
             ROOT / "tools" / "build_notebook.py", ROOT / "tools" / "notebook_template.py",
             ROOT / "tutorials" / "README.md", ROOT / "docs" / "release-verification.md", ROOT / "STATUS.md",
             ROOT / "README.md", ROOT / "weights" / "bart-large-cnn" / "config.json",
             ROOT / "weights" / "bart-large-cnn" / "generation_config.json"]
manifest = {str(p.relative_to(ROOT)).replace("\\", "/"): sha(p) for p in inspected}
(OUT / "source_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
print(json.dumps(results, indent=2, default=str))
